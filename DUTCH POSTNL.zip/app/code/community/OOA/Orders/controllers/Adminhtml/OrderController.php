<?php
/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */

/**
 * Orders controller
 */
class OOA_Orders_Adminhtml_OrderController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
        $this->_title($this->__('Sales'))->_title($this->__('Orders - Parcelware'));
        $this->loadLayout();
        $this->_setActiveMenu('sales/sales');
        $this->_addContent($this->getLayout()->createBlock('ooa_orders/adminhtml_sales_order'));
        $this->renderLayout();
    }
    public function gridAction()
    {
        $this->loadLayout();
        $this->getResponse()->setBody(
            $this->getLayout()->createBlock('ooa_orders/adminhtml_sales_order_grid')->toHtml()
        );
    }
    public function exportOOATNTpostfCsvAction()
    {

    	$tablePrefix = (string) Mage::getConfig()->getTablePrefix();
    	$collection = Mage::getResourceModel('sales/order_collection');
    	$collection->getSelect()
    	->join(array('a' => $tablePrefix . 'sales_flat_order_address'), 'main_table.entity_id = a.parent_id AND a.address_type != \'billing\'', array(
    			'city'       => 'city',
    			'country_id' => 'country_id'
    	));
    	$collection->getSelect()
    	->join(array('c' => $tablePrefix . 'customer_group'), 'main_table.customer_group_id = c.customer_group_id', array(
    			'customer_group_code' => 'customer_group_code'
    	));
    	$collection->addExpressionFieldToSelect(
    			'fullname',
    			'CONCAT({{customer_firstname}}, \' \', {{customer_lastname}})',
    			array('customer_firstname' => 'main_table.customer_firstname', 'customer_lastname' => 'main_table.customer_lastname'));
    	$collection->addExpressionFieldToSelect(
    			'products',
    			'(SELECT GROUP_CONCAT(\' \', x.name)
                    FROM ' . $tablePrefix . 'sales_flat_order_item x
                    WHERE {{entity_id}} = x.order_id
                        AND x.product_type != \'configurable\')',
    			array('entity_id' => 'main_table.entity_id')
    	)
    	;
    	$collection->addFieldToFilter('status', array("in" => array(Mage::getStoreConfig('carriers/tntpostf/MODULE_SH_TNT_STATUS_PARCELWARE'))));
    	
    	$collection->load();
    	
    	$cy = Mage::getModel('directory/country');
    	
    	$sep = ";";
    	$contents = "ReferenceNr".$sep."Title".$sep."Name1".$sep."Name2".$sep."Name3".$sep."Street".$sep."HomeNr".$sep."HomeNrExt".$sep."ZIP".$sep."City".$sep."AddressDetails".$sep."Country".$sep."Telephone".$sep."MobileTelephone".$sep."FAX".$sep."Email".$sep."TAXnr".$sep."Remark\n";
    	
    	foreach ($collection as $order) {
    		$row = $order->getShippingAddress()->getData();
    	
    		if ($row['country_id'] == 'NL') {
    			$address_parts = $this->split_address($row['street']);
    			$row['street'] = $address_parts["streetname"];
    			$row['HomeNr'] = $address_parts["streetnr"] . $address_parts["streetnrext"];
    		}
    	
    		$contents .= $order->getIncrementId().$sep;
    		$contents .= $sep;
    		$contents .= $row['firstname']." ".$row['middlename']." ".$row['lastname'].$sep;
    		$contents .= $sep;
    		$contents .= $sep;
    		$contents .= $row['street'].$sep;
    		$contents .= $row['HomeNr'].$sep;
    		$contents .= $sep;
    		$contents .= $row['postcode'].$sep;
    		$contents .= $row['city'].$sep;
    		$contents .= $sep;
    		$contents .= $cy->load($row['country_id'])->getName().$sep;
    		$contents .= $row['telephone'].$sep;
    		$contents .= $sep;
    		$contents .= $row['fax'].$sep;
    		$contents .= $row['email'].$sep;
    		$contents .= $sep;
    		$contents .= "\n";
    	};
    	
    	$this->_prepareDownloadResponse('postnl_parcelware.csv', $contents, 'text/csv');
    	 
    }
    
    protected function _isAllowed()
    {
    	return true;
    }

    public function split_address($full_address) {
    	list($address["streetname"]) = preg_split("/ [0-9]+/", $full_address);
    	list($leeg,$rest) = @preg_split("/" . $address["streetname"] . "/", $full_address);
    	preg_match("/[0-9]+/", $rest, $regs);
    	list($address["streetnr"]) = $regs;
    	list($leeg,$address["streetnrext"]) = @preg_split("/" . $address["streetnr"] . "/", $rest);
    	return $address;
    }
    
}
