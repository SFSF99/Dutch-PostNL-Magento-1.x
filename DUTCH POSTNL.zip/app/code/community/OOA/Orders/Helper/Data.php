<?php
/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */

/**
 * Orders data helper
 */
class OOA_Orders_Helper_Data extends Mage_Core_Helper_Abstract
{

}
