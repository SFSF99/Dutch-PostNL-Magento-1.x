<?php
/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */
class OOA_TNTpostf_Model_Heightvolume
{
   public function toOptionArray()
   {
       $options = array(
           array('value' => 0, 'label' => Mage::helper('tntpostf')->__('MODULE_SH_TNT_HEIGHT_VOLUME_11')),
           array('value' => 1, 'label' => Mage::helper('tntpostf')->__('MODULE_SH_TNT_HEIGHT_VOLUME_12')),
       );

       return $options;
   }
}
