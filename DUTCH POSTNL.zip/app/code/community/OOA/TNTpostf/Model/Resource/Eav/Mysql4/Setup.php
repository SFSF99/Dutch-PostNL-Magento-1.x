<?php

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */
class OOA_TNTpostf_Model_Resource_Eav_Mysql4_Setup extends Mage_Eav_Model_Entity_Setup
{
	/**
	 * @return array
	 */
	public function getDefaultEntities()
	{
		return array(
				'catalog_product' => array(
						'entity_model'      => 'catalog/product',
						'attribute_model'   => 'catalog/resource_eav_attribute',
						'table'             => 'catalog/product',
						'additional_attribute_table' => 'catalog/eav_attribute',
						'entity_attribute_collection' => 'catalog/product_attribute_collection',
						'attributes'        => array(
								'tntpostf_height' => array(
										'group'             => 'General',
										'label'             => 'PostNL height',
										'type'              => 'varchar',
										'input'             => 'text',
										'default'           => '0.0000',
										'class'             => 'validate-number',
										'backend'           => '',
										'frontend'          => '',
										'source'            => '',
										'global'            => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
										'visible'           => true,
										'required'          => true,
										'user_defined'      => true,
										'searchable'        => false,
										'filterable'        => false,
										'comparable'        => false,
										'visible_on_front'  => false,
										'visible_in_advanced_search' => false,
										'unique'            => false
								),
								'tntpostf_maxplet' => array(
										'group'             => 'General',
										'label'             => 'PostNL max/letter',
										'type'              => 'varchar',
										'input'             => 'text',
										'default'           => '1',
										'class'             => 'validate-digits',
										'backend'           => '',
										'frontend'          => '',
										'source'            => '',
										'global'            => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
										'visible'           => true,
										'required'          => true,
										'user_defined'      => true,
										'searchable'        => false,
										'filterable'        => false,
										'comparable'        => false,
										'visible_on_front'  => false,
										'visible_in_advanced_search' => false,
										'unique'            => false
								),
								'tntpostf_shipping' => array(
										'group'             => 'General',
										'label'             => 'PostNL shipping',
										'type'              => 'int',
										'input'             => 'boolean',
										'default'           => '1',
										'class'             => '',
										'backend'           => '',
										'frontend'          => '',
										'source'            => 'eav/entity_attribute_source_boolean',
										'global'            => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
										'visible'           => true,
										'required'          => false,
										'user_defined'      => true,
										'searchable'        => false,
										'filterable'        => false,
										'comparable'        => false,
										'visible_on_front'  => false,
										'visible_in_advanced_search' => false,
										'unique'            => false
								),
								'tntpostf_package' => array(
										'group'             => 'General',
										'label'             => 'PostNL package',
										'type'              => 'int',
										'input'             => 'boolean',
										'default'           => '1',
										'class'             => '',
										'backend'           => '',
										'frontend'          => '',
										'source'            => 'eav/entity_attribute_source_boolean',
										'global'            => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
										'visible'           => true,
										'required'          => false,
										'user_defined'      => true,
										'searchable'        => false,
										'filterable'        => false,
										'comparable'        => false,
										'visible_on_front'  => false,
										'visible_in_advanced_search' => false,
										'unique'            => false
								),
								'tntpostf_sealbag' => array(
										'group'             => 'General',
										'label'             => 'PostNL sealbag',
										'type'              => 'int',
										'input'             => 'boolean',
										'default'           => '0',
										'class'             => '',
										'backend'           => '',
										'frontend'          => '',
										'source'            => 'eav/entity_attribute_source_boolean',
										'global'            => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
										'visible'           => true,
										'required'          => false,
										'user_defined'      => true,
										'searchable'        => false,
										'filterable'        => false,
										'comparable'        => false,
										'visible_on_front'  => false,
										'visible_in_advanced_search' => false,
										'unique'            => false
								),
								//...
						)
				),
                //... define attributes for other model entities here
		);
	}		
}
