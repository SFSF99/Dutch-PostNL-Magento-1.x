<?php

$installer = $this;
 
$installer->installEntities();
