<?php
/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */

class OOA_TNTpostf_Block_Onepage_Payment_Methods extends Mage_Checkout_Block_Onepage_Payment_Methods
{

    public function getMethods()
    {
    	
    	//Get selected shipping method
    	$shippingMethod = Mage::getSingleton('checkout/session')->getQuote()->getShippingAddress()->getShippingMethod();

    	$shippingMethod = explode('_', $shippingMethod);
    	
    	// start original method 
        $methods = $this->getData('methods');
        if (is_null($methods)) {
            $quote = $this->getQuote();
            $store = $quote ? $quote->getStoreId() : null;
            $methods = $this->helper('payment')->getStoreMethods($store, $quote);
            $total = $quote->getBaseGrandTotal();
            // start tntpostf
            $cod = false;              
            foreach ($methods as $key => $method) {
              if (($method->getCode() == 'cod') and ($this->_canUseMethod($method))) {
                if (($shippingMethod[1] == 'CODLEHOCO') or ($shippingMethod[1] == 'CODPAHOCO')) {
                  $cod = true; 
                } else {
                  unset($methods[$key]);
                }
              }               
            }            
            // stop tntpostf 
            foreach ($methods as $key => $method) {
                if ($this->_canUseMethod($method)
                    && ($total != 0
                        || $method->getCode() == 'free'
                        || ($quote->hasRecurringItems() && $method->canManageRecurringProfiles()))) {
                    // start tntpostf      
                    if ($cod == true) {    
                      if ($method->getCode() == 'cod') {
                        $this->_assignMethod($method);
                      } else {
                        unset($methods[$key]);
                      }
                    } else {
                      $this->_assignMethod($method);
                    }    
                    // stop tntpostf
                }
                else {
                    unset($methods[$key]);
                }
            }
            $this->setData('methods', $methods);
        }
        return $methods;    	
    	// stop original method 

    }
}
