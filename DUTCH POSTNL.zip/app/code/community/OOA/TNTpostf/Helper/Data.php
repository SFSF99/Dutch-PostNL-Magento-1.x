<?php
/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */

/**
 * Shipping data helper
 */
class OOA_TNTpostf_Helper_Data extends Mage_Core_Helper_Abstract
{
    
}
